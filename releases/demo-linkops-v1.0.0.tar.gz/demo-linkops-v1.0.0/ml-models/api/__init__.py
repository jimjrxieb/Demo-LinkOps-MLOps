"""
ML Creator API Package

Provides FastAPI endpoints for creating ML models and AI agents.
"""

__version__ = "1.0.0"
__author__ = "DEMO-LinkOps Team"
