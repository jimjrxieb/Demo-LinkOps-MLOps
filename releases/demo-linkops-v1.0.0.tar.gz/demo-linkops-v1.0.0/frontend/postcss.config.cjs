/* eslint-env node */
/* eslint-disable no-undef */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
