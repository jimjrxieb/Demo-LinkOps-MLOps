#!/usr/bin/env python3
"""
Test Auto Tool Runner
====================

This script tests the Auto Tool Runner functionality without running it continuously.
It loads tools, executes them once, and verifies logging.
"""

import json
import os
import sys
import time
from pathlib import Path

# Add the project root to the Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Change to the project root directory for proper imports
os.chdir(project_root)

# Import the modules using the correct path
import sys

sys.path.insert(0, str(project_root / "unified-api"))

from logic.execution_logger import get_logs, init_logger, log_execution
from logic.executor import run_tool_command


def test_auto_runner():
    """Test the auto runner functionality."""
    print("🧪 Testing Auto Tool Runner...")

    # Initialize logger
    try:
        init_logger()
        print("✅ Logger initialized")
    except Exception as e:
        print(f"❌ Logger initialization failed: {e}")
        return False

    # Load auto-enabled tools
    tools_path = Path("db/mcp_tools")
    auto_tools = []

    if not tools_path.exists():
        print(f"❌ Tools directory not found: {tools_path}")
        return False

    for filename in os.listdir(tools_path):
        if filename.endswith(".json"):
            file_path = tools_path / filename
            try:
                with open(file_path) as f:
                    tool = json.load(f)
                    if tool.get("auto", False):
                        auto_tools.append(tool)
                        print(f"✅ Found auto tool: {tool.get('name', filename)}")
            except Exception as e:
                print(f"⚠️ Error reading {filename}: {e}")

    print(f"📊 Found {len(auto_tools)} auto-enabled tools")

    if not auto_tools:
        print("⚠️ No auto-enabled tools found")
        return True

    # Execute each auto tool
    for tool in auto_tools:
        name = tool.get("name", "unknown")
        command = tool.get("command")

        if not command:
            print(f"⚠️ Tool {name} has no command, skipping")
            continue

        print(f"▶️ Testing tool: {name}")

        start = time.time()
        result = run_tool_command(command)
        duration_ms = int((time.time() - start) * 1000)

        # Log the execution
        log_execution(
            tool_name=name,
            command=command,
            stdout=result.get("stdout", ""),
            stderr=result.get("stderr", ""),
            returncode=result.get("returncode", -1),
            duration_ms=duration_ms,
        )

        success = result.get("success", False)
        status = "✅" if success else "❌"
        print(f"{status} Tool {name} completed in {duration_ms}ms (success: {success})")

        # Show output preview
        stdout = result.get("stdout", "").strip()
        if stdout:
            lines = stdout.split("\n")
            preview = "\n".join(lines[:3])  # Show first 3 lines
            if len(lines) > 3:
                preview += f"\n... ({len(lines) - 3} more lines)"
            print(f"📄 Output preview:\n{preview}")

    # Get recent logs
    print("\n📋 Recent execution logs:")
    logs = get_logs(limit=5)
    for log in logs:
        status = "✅" if log.get("success") else "❌"
        print(
            f"{status} {log.get('tool_name', 'unknown')} - {log.get('duration_ms', 0)}ms - {log.get('timestamp', 'unknown')}"
        )

    print("\n🎉 Auto Runner test completed successfully!")
    return True


if __name__ == "__main__":
    success = test_auto_runner()
    sys.exit(0 if success else 1)
