#!/usr/bin/env python3
"""
Auto Tool Runner
===============

This script automatically runs MCP tools that are marked with "auto": true
in their configuration files. It polls the tools directory every 5 minutes
and executes any auto-enabled tools, logging their results.
"""

import json
import logging
import os
import sys
import time
from pathlib import Path

# Add the project root to the Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Change to the project root directory for proper imports
os.chdir(project_root)

# Import the modules using the correct path
import sys

sys.path.insert(0, str(project_root / "unified-api"))

from logic.execution_logger import init_logger, log_execution
from logic.executor import run_tool_command

# Configuration
TOOLS_PATH = "db/mcp_tools"
POLL_INTERVAL_SECONDS = 300  # every 5 minutes

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler("auto_runner.log")],
)
logger = logging.getLogger(__name__)

print("🔁 Auto Runner Started — Watching for auto-enabled tools...")
logger.info("Auto Runner initialized")


def load_tools():
    """Load all auto-enabled tools from the mcp_tools directory."""
    tools = []
    tools_dir = Path(TOOLS_PATH)

    if not tools_dir.exists():
        logger.error(f"Tools directory not found: {TOOLS_PATH}")
        return tools

    for filename in os.listdir(tools_dir):
        if filename.endswith(".json"):
            file_path = tools_dir / filename
            try:
                with open(file_path) as f:
                    tool = json.load(f)
                    if tool.get("auto", False):
                        tools.append(tool)
                        logger.info(
                            f"Found auto-enabled tool: {tool.get('name', filename)}"
                        )
            except Exception as e:
                logger.error(f"Error reading {filename}: {e}")

    return tools


def run_auto_tools():
    """Execute all auto-enabled tools and log their results."""
    tools = load_tools()
    logger.info(f"Found {len(tools)} auto-enabled tools")

    for tool in tools:
        name = tool.get("name", "unknown")
        command = tool.get("command")

        if not command:
            logger.warning(f"Tool {name} has no command defined, skipping")
            continue

        logger.info(f"Running auto tool: {name}")
        print(f"▶️ Running auto tool: {name}")

        start = time.time()
        result = run_tool_command(command)
        duration_ms = int((time.time() - start) * 1000)

        # Log the execution
        log_execution(
            tool_name=name,
            command=command,
            stdout=result.get("stdout", ""),
            stderr=result.get("stderr", ""),
            returncode=result.get("returncode", -1),
            duration_ms=duration_ms,
        )

        success_status = "✅" if result.get("success", False) else "❌"
        print(f"{success_status} Logged result for {name} (duration: {duration_ms} ms)")
        logger.info(
            f"Completed {name} in {duration_ms}ms (success: {result.get('success', False)})"
        )


def main():
    """Main loop for the auto runner."""
    # Initialize the logger database
    try:
        init_logger()
        logger.info("Execution logger initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize execution logger: {e}")
        print(f"❌ Failed to initialize logger: {e}")
        return

    print("🚀 Auto Runner is now running...")
    print(f"📁 Monitoring tools in: {TOOLS_PATH}")
    print(f"⏰ Polling interval: {POLL_INTERVAL_SECONDS} seconds")
    print("Press Ctrl+C to stop")
    print("-" * 50)

    try:
        while True:
            run_auto_tools()
            print(f"⏳ Sleeping {POLL_INTERVAL_SECONDS}s...")
            logger.info(f"Sleeping for {POLL_INTERVAL_SECONDS} seconds")
            time.sleep(POLL_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        print("\n🛑 Auto Runner stopped by user")
        logger.info("Auto Runner stopped by user")
    except Exception as e:
        print(f"❌ Auto Runner error: {e}")
        logger.error(f"Auto Runner error: {e}")


if __name__ == "__main__":
    main()
